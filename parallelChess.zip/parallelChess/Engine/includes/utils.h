// #pragma once

// #include <stdbool.h>

// inline bool isLegalCharacter(char c){
//     switch (c)
//     {

//     case 'k':
//     case 'q':
//     case 'r':
//     case 'b':
//     case 'n':
//     case 'p':
//     case 'K':
//     case 'Q':
//     case 'R':
//     case 'B':
//     case 'N':
//     case 'P':
//         return true; 
//     default:
//         return false;

//     }
// }