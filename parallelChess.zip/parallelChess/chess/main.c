// THIS CODE IS AUTHORED BY SERENOV. 
#include"include.h"
int main(){
    game();
    return 0;
}
