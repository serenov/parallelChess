short de(short piece);
short kingthreat(short board[], short pos);
