short stalemate(short board[], short turn);
