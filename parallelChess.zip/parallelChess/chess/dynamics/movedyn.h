short picker(short board[], short pos, short* possible);
void movmkr(short destpos, short board[], short pos, short* possible);
short psmkr(short board[], short pos, short destpos);
