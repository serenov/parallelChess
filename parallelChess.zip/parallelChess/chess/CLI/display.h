char dcd(int value);
void unit(short board[], short start, char status[]);
void display(short b[], char status[]);