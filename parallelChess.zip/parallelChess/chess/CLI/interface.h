char* t(short turn);
short d(short turn);
void decode(short possible[], char status[], char c);
short io(short board[], char status[], short possible[], short turn, short *checkmate);
void game();