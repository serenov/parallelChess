void RevertEnpassant(short *board, short *list);
void RevertCastle(short *board, short *list);
void RevertRegular(short *board, short *list);
void RevertPromotions(short *board, short *list);
void undo(short *board, short *list, short flag);
